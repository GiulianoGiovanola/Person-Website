var imagenes=["assets/imagenes/lago.jpg","assets/imagenes/munecoconluz.jpg","assets/imagenes/tatuaje.jpg"];
var sliderposition=0;
var imagenes2=["assets/imagenes/mujerroja.jpg","assets/imagenes/china.jpg","assets/imagenes/viejo.jpg"];
var nombres=["LILLIAN PERKINS", "MAGGIE FLEMING","SEAN WELLS"];
var texto=["Yes, I was once a Jedi Knight the same as your father. I wish I'd known him. Our ships have completed their scan of the area and found nothing. If the Millennium Falcon went into light-speed, it'll be on the other side of the galaxy by now.",
          "If you end your training now, if you choose the quick and easy path, as Vader did, you will become an agent of evil. Our ships have completed their scan of the area and found nothing. If the Millennium Falcon went into light-speed.",
          "He says he's the property of Obi-Wan Kenobi, a resident of these parts. Yes, I was once a Jedi Knight the same as your father. I wish I'd known him."];
var ip=["Elastic Themes","<a id='botondetestimonio' class='bt01' href='https://twitter.com/NetflixES/status/1194948739963801601'>Marco Interactive</a>","<a id='botondetestimonio' class='bt01' href='https://twitter.com/Santiago_Arau/status/1194442826634809344'>Design Goods</a>"];
var testimonioposition= 0;

function slide(num) { //el parametro va a valer 1 o -1, por lo que suma o resta dependiendo lo que se le pase. la idea es un onclick pasa 1 y el otro -1
    sliderposition=sliderposition+num;
    if (sliderposition>=imagenes.length) {
        sliderposition=0;
    }
    if (sliderposition<0) {
        sliderposition=imagenes.length-1;
    }


    document.getElementById("carruselprincipal").style.backgroundImage="linear-gradient(180deg, rgba(17, 17, 17, 0.6), rgba(60, 60, 60, 0.2)),url("+imagenes[sliderposition]+") , linear-gradient(90deg, #40424b, #1c1d24)";
}

slide(0);

function testimonio(num) { //el parametro va a valer 1 o -1, por lo que suma o resta dependiendo lo que se le pase. la idea es un onclick pasa 1 y el otro -1
    testimonioposition=testimonioposition+num;
    if (testimonioposition>=imagenes2.length && 
        testimonioposition>=nombres.length && 
        testimonioposition>=texto.length && 
        testimonioposition>=ip.length) {
        testimonioposition=0;
    }
    if (testimonioposition<0) {
        testimonioposition=imagenes2.length-1;
        testimonioposition=nombres.length-1;
        testimonioposition=texto.length-1;
        testimonioposition=ip.length-1;
    }


    document.getElementById("imgtestimonio").style.backgroundImage="url("+imagenes2[testimonioposition]+")width: 5em; height: 5em, border-radius: 3em, border: 0.2em solid #faaf52, display: flex,";
    document.getElementById("nombredetestimonio").innerHTML= nombres[testimonioposition];
    document.getElementById("textodetestimonio").innerHTML=texto[testimonioposition];
    document.getElementById("botondetestimonio").innerHTML= ip[testimonioposition];
}

testimonio(0);